public enum TypeRole {
    USER,
    ADMIN
}
