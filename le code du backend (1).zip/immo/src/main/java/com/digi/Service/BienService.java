package com.digi.Service;





import java.util.List;
import java.util.Optional;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.digi.entities.BienImmobilier;

import com.digi.repository.BienRepository;


import jakarta.transaction.Transactional;

import lombok.Getter;



@Getter

@Service
@Transactional
@Repository
public class BienService {

  
   @Autowired
    private BienRepository bienReposity;
   
  


    private final Logger log = LoggerFactory.getLogger(BienService.class);
    private final BienRepository bienRepository;


    public BienService(BienRepository bienRepository) {
        this.bienRepository = bienRepository;
    }

    public BienImmobilier save(BienImmobilier biens) {
        log.debug("Request to save biens : {}", biens);
        return bienRepository.save(biens);
    }
    
    public BienImmobilier update(BienImmobilier biens) {
        log.debug("Request to update biens : {}", biens);
        return bienRepository.save(biens);
    }

    public Optional<BienImmobilier> partialUpdate(BienImmobilier biens) {
        log.debug("Request to partially update biens : {}", biens);

        return bienRepository
            .findById(biens.getId())
            .map(existingbiens -> {
                if (biens.getName_bien()!= null) {
                    existingbiens.setName_bien(biens.getName_bien());
                }
                if (biens.getDescription() != null) {
                    existingbiens.setDescription(biens.getDescription());
                }
                if (biens.getPrix() != null) {
                    existingbiens.setPrix(biens.getPrix());
                }
                if(biens.getDisponibilite() != null){
                    existingbiens.setDisponibilite(biens.getDisponibilite());
                }
                if (biens.getImageBien() != null) {
                    existingbiens.setImageBien(biens.getImageBien());
                }
                if (biens.getImageBienContentType() != null) {
                    existingbiens.setImageBienContentType(biens.getImageBienContentType());
                }

                return existingbiens;
            })
            .map(bienRepository::save);
    }



    public List<BienImmobilier> findAll() {
        log.debug("Request to get all Biens");
        return bienRepository.findAll();
    }
    
   
   public Optional<BienImmobilier> findOne(String id) {
       log.debug("Request to get Biens : {}", id);
       return bienRepository.findById(id);
   }

   /**
    * Delete the produits by id.
    *
    * @param id the id of the entity.
    */
   public void delete(Long id) {
       log.debug("Request to delete Biens : {}", id);
       bienRepository.deleteById(id);
   }


//    public List<BienImmobilier>findByCategorieId(Long categorie_id){
//     return bienRepository.findByCategoryId(categorie_id);
// }
}
