package com.digi.Service;



import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.digi.entities.Avis;
import com.digi.entities.Utilisateur;
import com.digi.repository.AvisRepository;

import lombok.AllArgsConstructor;
@AllArgsConstructor
@Service
public class AvisService {
    private final AvisRepository avisRepository;
	public void creer(Avis avis){
        Utilisateur utilisateur = (Utilisateur) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        avis.setUtilisateur(utilisateur);
        this.avisRepository.save(avis);
        
    }
    
}
