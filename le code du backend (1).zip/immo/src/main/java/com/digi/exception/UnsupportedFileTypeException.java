package com.digi.exception;

public class UnsupportedFileTypeException  extends RuntimeException{
    public UnsupportedFileTypeException(String message){
        super(message);
    }
    
}
