package com.digi.entities;

public enum TypeRole {
    USER,
    ADMIN

}
