package com.digi.entities;




import java.util.ArrayList;
import java.util.List;


import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class BienImmobilier {

    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String Name_bien;
    private String description;
    private Float prix;
    private String disponibilite;
    private int nombrePiece;

    @Lob
   
    private byte[] imageBien;

    private String imageBienContentType;

   @ManyToOne(fetch = FetchType.LAZY)
   @JsonIgnoreProperties(value = { "biens", "hibernateLazyInitializer" }, allowSetters = true)
   private Categorie categorie; 
   

   public BienImmobilier imageBien(byte[] imageBien) {
    this.setImageBien(imageBien);
    return this;
}
    
   public BienImmobilier imageBienContentType(String imageBienContentType) {
    this.imageBienContentType = imageBienContentType;
    return this;
}

    

    

    
    
}
