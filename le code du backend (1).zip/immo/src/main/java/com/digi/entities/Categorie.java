package com.digi.entities;

import java.util.Collection;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;

@Entity
public class Categorie {
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nomCategotie;
    
    @OneToMany(mappedBy = "categorie")
    private List<BienImmobilier> biens;


    

    public Categorie() {
    }

    public Categorie(Long id, String nomCategotie, List<BienImmobilier> biens) {
        this.id = id;
        this.nomCategotie = nomCategotie;
        this.biens = biens;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomCategotie() {
        return nomCategotie;
    }

    public void setNomCategotie(String nomCategotie) {
        this.nomCategotie = nomCategotie;
    }

    public Collection<BienImmobilier> getBiens() {
        return biens;
    }

    public void setBiens(List<BienImmobilier> biens) {
        this.biens = biens;
    }

 
    

}
