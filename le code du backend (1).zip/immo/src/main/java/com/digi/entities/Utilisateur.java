package com.digi.entities;



import jakarta.persistence.*;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import lombok.*;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "utilisateur")
public class Utilisateur implements UserDetails {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "mot_de_passe")
    private String mdp;
    private String nom;
    
    private String email;
    private boolean actif = true;
    @OneToOne(cascade = CascadeType.ALL)
    private Role role;
    
    
    
    
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMdp() {
		return mdp;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isActif() {
		return actif;
	}

	public void setActif(boolean actif) {
		this.actif = actif;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	@Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.singletonList(new SimpleGrantedAuthority("ROLE_"+this.role.getLibelle()));
    }

    @Override
    public String getPassword() {
        return this.mdp;
    }

    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return this.actif;
    }

    @Override
    public boolean isAccountNonLocked() {
        return this.actif;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return this.actif;
    }

    @Override
    public boolean isEnabled() {
        return this.actif;
    }
    
    
} 

// @Entity
// public class Utilisateur {
	
// 	@Id
// 	@GeneratedValue(strategy = GenerationType.IDENTITY)
// 	private long id;
// 	private String name;
// 	private String password;
// 	private String email;
	
// 	@ManyToOne
//     @JoinColumn(name = "role_id") // Colonne de jointure avec l'entité Role
//     private Role role;
	
	 
// 	public Utilisateur() {
// 	}
// 	public Utilisateur(long id, String name, String password, String email, Role roles) {
// 		this.id = id;
// 		this.name = name;
// 		this.password = password;
// 		this.email = email;
// 		this.role = roles;
// 	}
// 	public long getId() {
// 		return id;
// 	}
// 	public void setId(long id) {
// 		this.id = id;
// 	}
// 	public String getName() {
// 		return name;
// 	}
// 	public void setName(String name) {
// 		this.name = name;
// 	}
// 	public String getPassword() {
// 		return password;
// 	}
// 	public void setPassword(String password) {
// 		this.password = password;
// 	}
// 	public String getEmail() {
// 		return email;
// 	}
// 	public void setEmail(String email) {
// 		this.email = email;
// 	}
// 	public Role getRole() {
// 		return role;
// 	}
// 	public void setRole(Role role) {
// 		this.role = role;
// 	}
	
	
	
	
// }
