package com.digi.entities;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.*;

// package entite;


import lombok.*;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "role")
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Enumerated(EnumType.STRING)
    private TypeRole libelle;
   

    
    
    
}
