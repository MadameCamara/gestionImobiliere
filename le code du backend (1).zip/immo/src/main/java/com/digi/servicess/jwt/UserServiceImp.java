// package com.digi.servicess.jwt;

// import java.util.Collection;
// import java.util.List;
// import java.util.stream.Collectors;

// import org.springframework.security.core.authority.SimpleGrantedAuthority;
// import org.springframework.security.core.userdetails.User;
// import org.springframework.security.core.userdetails.UserDetails;
// import org.springframework.security.core.userdetails.UserDetailsService;
// import org.springframework.security.core.userdetails.UsernameNotFoundException;
// import org.springframework.stereotype.Service;

// import com.digi.entities.Utilisateur;
// import com.digi.repository.UserRepository;

// @Service
// public class UserServiceImp  implements UserDetailsService{

//     private final UserRepository userRepository;

//     public UserServiceImp(UserRepository userRepository){
//         this.userRepository=userRepository;
//     }
//     @Override
//      public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
//       Utilisateur user = userRepository.findByEmail(email)
//             .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));

//     // Convertissez les rôles du modèle Utilisateur en objets SimpleGrantedAuthority
//     @SuppressWarnings("unchecked")
// List<SimpleGrantedAuthority> authorities = ((Collection<SimpleGrantedAuthority>) user.getRole())
//             .stream()
//             .map(role -> new SimpleGrantedAuthority("ROLE_" + role))  // Assurez-vous que vos rôles commencent par "ROLE_"
//             .collect(Collectors.toList());

//     return User.withUsername(user.getEmail())
//             .password(user.getPassword())
//             .authorities(authorities)
//             .build();
//      }  
// }
