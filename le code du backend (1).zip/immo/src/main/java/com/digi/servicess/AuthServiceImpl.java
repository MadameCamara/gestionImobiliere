// package com.digi.servicess;




// import org.springframework.beans.BeanUtils;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.security.crypto.password.PasswordEncoder;
// import org.springframework.stereotype.Service;

// import com.digi.dto.SignupRequest;
// import com.digi.entities.Role;
// import com.digi.entities.Utilisateur;
// import com.digi.repository.RoleRepository;
// import com.digi.repository.UserRepository;


// @Service
// public class AuthServiceImpl implements AuthService {

	
// 	private final UserRepository userRepository;
	
// 	private final PasswordEncoder passwordEncoder;

// 	private final RoleRepository roleRepository;

	
	
// 	@Autowired
// 	public AuthServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder,RoleRepository roleRepository) {
// 		super();
// 		this.userRepository = userRepository;
// 		this.passwordEncoder = passwordEncoder;
// 		this.roleRepository = roleRepository;
// 	}



// 	@Override
// 	public boolean createUser(SignupRequest signupRequest) {
// 		//verifier si l'utilisateur existe
// 		if(userRepository.existsByEmail(signupRequest.getEmail()))
// 		{
// 			return false;
// 		}
// 		Utilisateur user =new Utilisateur();
// 		BeanUtils.copyProperties(signupRequest, user);
// //		user.setEmail(signupRequest.getEmail());
// //		user.setName(signupRequest.getName());
// //		user.setPassword(signupRequest.getPassword());
		
// 		//hash the password saving
// 		String hasPassword=passwordEncoder.encode(signupRequest.getPassword());
// 		user.setPassword(hasPassword);
// 		// Attribuer automatiquement le rôle "user" à cet utilisateur
		
//         Role userRole = new Role("ROLE_USER");
//         roleRepository.save(userRole);
// 		userRepository.save(user);
// 		return true;
// 	}

// }
