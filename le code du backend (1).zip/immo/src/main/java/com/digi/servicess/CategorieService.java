package com.digi.servicess;

import java.util.List;

import com.digi.entities.Categorie;

public interface CategorieService {
     List<Categorie> getAllCategories();

    Categorie getCategorieById(Long id);

    Categorie addCategorie(Categorie categorie);

    Categorie updateCategorie(Long id, Categorie categorie);

    void deleteCategorie(Long id);
    
}
