// package com.digi.servicess;

// import com.digi.dto.SignupRequest;

// public interface AuthService {

// 	boolean createUser(SignupRequest signupRequest);

// }
