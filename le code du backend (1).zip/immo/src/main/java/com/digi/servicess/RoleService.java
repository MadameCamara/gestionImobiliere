// package com.digi.servicess;

// import org.springframework.stereotype.Service;

// import com.digi.entities.Role;
// import com.digi.repository.RoleRepository;

// import jakarta.transaction.Transactional;

// @Service
// @Transactional
// public class RoleService {
    
//     public final RoleRepository roleRepository = null;
//     public void saveRole(Role role) {
//         roleRepository.save(role);
//     }
// }
