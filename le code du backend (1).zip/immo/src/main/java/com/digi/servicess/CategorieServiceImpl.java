package com.digi.servicess;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digi.entities.Categorie;
import com.digi.repository.CategorieRepository;

@Service
public class CategorieServiceImpl implements CategorieService {

      @Autowired
    private final  CategorieRepository categorieRepository;
    

    public CategorieServiceImpl(CategorieRepository categorieRepository) {
        this.categorieRepository = categorieRepository;
    }

    @Override
    public List<Categorie> getAllCategories() {
        return categorieRepository.findAll();
    }

    @Override
    public Categorie getCategorieById(Long id) {
        Optional<Categorie> optionalCategorie = categorieRepository.findById(id);
        return optionalCategorie.orElse(null);
    }

    @Override
    public Categorie addCategorie(Categorie categorie) {
        return categorieRepository.save(categorie);
    }

    @Override
    public Categorie updateCategorie(Long id, Categorie categorie) {
        Categorie existingCategorie = getCategorieById(id);
        if (existingCategorie != null) {
            existingCategorie.setNomCategotie(categorie.getNomCategotie());
            return categorieRepository.save(existingCategorie);
        }
        return null;
    }

    @Override
    public void deleteCategorie(Long id) {
        categorieRepository.deleteById(id);
    }
    
    
}
