package com.digi.dto;

public class BienImmobilierDto {
    private Long id;
    private String name_bien;
    private String description;
    private Float prix;
    private Boolean disponibilite;
    private byte[] imageBytes;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName_bien() {
        return name_bien;
    }
    public void setName_bien(String name_bien) {
        this.name_bien = name_bien;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Float getPrix() {
        return prix;
    }
    public void setPrix(Float float1) {
        this.prix = float1;
    }
    public Boolean getDisponibilite() {
        return disponibilite;
    }
    public void setDisponibilite(Boolean disponibilite) {
        this.disponibilite = disponibilite;
    }
    public byte[] getImageBytes() {
        return imageBytes;
    }
    public void setImageBytes(byte[] imageBytes) {
        this.imageBytes = imageBytes;
    }


    
    
}
