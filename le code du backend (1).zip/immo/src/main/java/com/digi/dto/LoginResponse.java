// package com.digi.dto;

// public class LoginResponse {
//     private String jwtToken;
//     @SuppressWarnings("unused")
//     private String role;

//     public LoginResponse(String jwtToken, String role){
//         this.jwtToken=jwtToken;
//         this.role=role;
//     }
    
//     public String getJwString() {
//         return jwtToken;
//     }

//     public void setJwtToken(String jwtToken) {
//         this.jwtToken = jwtToken;
//     }

// }
