package com.digi.dto;

public record AuthentificationDTO(String username,String password) {
    
}
