 package com.digi.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RestController;

import com.digi.Service.UtilisateurService;
import com.digi.entities.Role;
import com.digi.entities.Utilisateur;

import lombok.AllArgsConstructor;

@AllArgsConstructor
 @RestController
 @CrossOrigin(origins = "http://localhost:4200")

 public class RoleController {
     
    @Autowired
    private final UtilisateurService utilisateurService;

    @GetMapping("/role")
    public ResponseEntity<Role> getUserRole() {
        // Récupérer l'utilisateur connecté
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Récupérer le rôle de l'utilisateur
        Utilisateur utilisateur = utilisateurService.loadUserByUsername(username);
        Role role = utilisateur.getRole(); // Supposons que la méthode pour récupérer le rôle de l'utilisateur soit getRole()

        return ResponseEntity.ok(role);
    }
    
 }
