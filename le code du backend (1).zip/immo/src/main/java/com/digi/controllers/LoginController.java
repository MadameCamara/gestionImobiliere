// package com.digi.controllers;


// import java.util.Optional;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.HttpStatus;

// import org.springframework.http.ResponseEntity;
// import org.springframework.security.authentication.AuthenticationManager;
// import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
// import org.springframework.security.core.AuthenticationException;
// import org.springframework.security.core.userdetails.UserDetails;
// import org.springframework.security.core.userdetails.UsernameNotFoundException;
// import org.springframework.web.bind.annotation.CrossOrigin;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;

// import com.digi.dto.LoginRequest;
// import com.digi.dto.LoginResponse;
// import com.digi.entities.Role;
// import com.digi.entities.Utilisateur;
// import com.digi.repository.UserRepository;
// import com.digi.servicess.jwt.UserServiceImp;
// import com.digi.utils.JwtUtil;



// @RestController
// @RequestMapping("/login")
// @CrossOrigin(origins = "http://localhost:4200")
// public class LoginController {

//     private  final AuthenticationManager authenticationManager;
//     private final UserServiceImp userService; 
//     private final JwtUtil jwtUtil;
//     @Autowired
//     private UserRepository userRepository;
//     @Autowired
//     public LoginController(AuthenticationManager authenticationManager,UserServiceImp userService,JwtUtil jwtUtil){
//         this.authenticationManager=authenticationManager;
//         this.userService=userService;
//         this.jwtUtil=jwtUtil;
//     }

    
//     @PostMapping
//     public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest loginRequest) {
//         try {
//             authenticationManager.authenticate(
//                 new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword())
//             );
//         } catch (AuthenticationException e) {
//             return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
//         }
    
//         UserDetails userDetails;
//         try {
//             userDetails = userService.loadUserByUsername(loginRequest.getEmail());
//         } catch (UsernameNotFoundException e) {
//             return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
//         }
    
//         // Récupérer le rôle de l'utilisateur
//         String role = userDetails.getAuthorities().iterator().next().getAuthority();

    
//         // Générer le jeton JWT
//         String jwt = jwtUtil.generateToken(userDetails.getUsername());
    
//         // Créer la réponse
//         LoginResponse response = new LoginResponse(jwt, role);
    
//         // Retourner la réponse avec le statut OK
//         return ResponseEntity.ok(response);
//     }

//      @GetMapping("/{userId}/role")
//     public ResponseEntity<String> getUserRole(@PathVariable Long userId) {
//         // Recherchez l'utilisateur par son identifiant
//         Optional<Utilisateur> userOptional = userRepository.findById(userId);
        
//         if (userOptional.isPresent()) {
//             // Récupérez le rôle de l'utilisateur
//             Utilisateur user = userOptional.get();
//             Role role = user.getRole();
//             if (role != null) {
//                 return ResponseEntity.ok(role.getName());
//             } else {
//                 return ResponseEntity.notFound().build();
//             }
//         } else {
//             return ResponseEntity.notFound().build();
//         }
//     }
    
// }
