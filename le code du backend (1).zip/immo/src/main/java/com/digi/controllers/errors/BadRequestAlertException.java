package com.digi.controllers.errors;

public class BadRequestAlertException {
    
}
