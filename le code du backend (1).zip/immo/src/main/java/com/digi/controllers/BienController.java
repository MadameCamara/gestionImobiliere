package com.digi.controllers;


import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.digi.Service.BienService;
import com.digi.entities.BienImmobilier;
;



@RestController
@RequestMapping("/biens")
 @CrossOrigin(origins = "http://localhost:4200")
public class BienController {


    @Autowired
    private final BienService bienService;


    public BienController( BienService bienService) {
        this.bienService = bienService;
    }
 
   
   
    //@PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/create")
    public ResponseEntity<BienImmobilier> createBien(@RequestBody BienImmobilier bien) throws URISyntaxException{
      
        BienImmobilier result = bienService.save(bien);
        return ResponseEntity
                .created(new URI("/api/biens/" + result.getId()))
                .body(result);
    }

     @PutMapping("/udapte")
    public ResponseEntity<BienImmobilier> updateBien(@RequestBody BienImmobilier bien) {
        BienImmobilier result = bienService.update(bien);
        return ResponseEntity.ok().body(result);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<BienImmobilier> partialUpdateBien(@PathVariable Long id, @RequestBody BienImmobilier bien) {
        Optional<BienImmobilier> result = bienService.partialUpdate(bien);
        return result.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/liste")
    public ResponseEntity<List<BienImmobilier>> getAllBiens() {
        List<BienImmobilier> biens = bienService.findAll();
        
        return ResponseEntity.ok().body(biens);
    }

    @GetMapping("/bien/{id}")
    public ResponseEntity<BienImmobilier> getBienById(@PathVariable String id) {
        Optional<BienImmobilier> bien = bienService.findOne(id);
        return bien.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteBien(@PathVariable Long id) {
        bienService.delete(id);
        return ResponseEntity.noContent().build();
    }

    // @GetMapping("/byCategory/{categorie_id}")
    // public ResponseEntity<List<BienImmobilier>> getBiensByCategory(@PathVariable Long categorie_id) {
    //     List<BienImmobilier> biens = bienService.findByCategorieId(categorie_id);
    //     return ResponseEntity.ok().body(biens);
    // }
}
