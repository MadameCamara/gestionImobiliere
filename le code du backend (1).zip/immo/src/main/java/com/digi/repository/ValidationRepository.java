// package com.digi.repository;

// import java.util.Optional;

// import org.springframework.data.repository.CrudRepository;
// import org.springframework.stereotype.Repository;

// import com.digi.entities.Validation;

// @Repository
// public interface ValidationRepository extends CrudRepository<Validation,Integer>{
//     Optional<Validation> findByCode(String code);
// }
