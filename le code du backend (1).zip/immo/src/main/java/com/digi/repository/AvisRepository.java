package com.digi.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.digi.entities.Avis;

@Repository
public interface AvisRepository  extends CrudRepository<Avis,Integer>{
    
}
