package com.digi.repository;







import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;


import com.digi.entities.BienImmobilier;

@Repository
public interface BienRepository  extends JpaRepository <BienImmobilier,Long>{

    Optional<BienImmobilier> findById(String id);

     

    
}
