package com.digi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImmoApplicationTests {

	@Test
	void contextLoads() {
	}

}
